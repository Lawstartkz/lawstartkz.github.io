Исправление (4 файла + 1 в папке data). Ничего не заменяйте и не удаляйте.

A. Три файла в корень репозитория: Add file > Upload files, выберите
   lawstart-nav.js, lawstart-catalog.js, lawstart-legal-english.js
   (README_RU.txt загружать не нужно).
B. Файл data/qa.json: Add file > Create new file, в поле имени введите
   data/qa.json (слэш создаст папку), вставьте содержимое из qa.json
   (4 строки), Commit changes.
После публикации (пара минут) откройте:
   https://lawstartkz.github.io/data/qa.json  (должен показать JSON)
   https://lawstartkz.github.io/catalog.html  (работает меню и каталог)
Раздел «Вопросы и ответы» покажет «опубликованных вопросов пока нет».
